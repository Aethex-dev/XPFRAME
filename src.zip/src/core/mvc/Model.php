<?php

namespace xenonmc\xpframe\core\mvc;

class Model
{
    public function __construct()
    {
    }
}