<?php

namespace xenonmc\xpframe\core\app;

interface App
{
    public function __construct();
    public function run();
}