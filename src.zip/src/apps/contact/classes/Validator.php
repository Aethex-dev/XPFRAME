<?php

namespace xenonmc\xpframe\apps\contact\classes;

class Validator
{
    public function __construct($p)
    {
        $_SESSION["errors"] = [];
        $r = 0;
        if (empty(trim($p["email"]))) {
            $_SESSION["errors"][0] = "Please enter your email address";
        } else {
            $r++;
        }  

        if (empty(trim($p["message"]))) {
            $_SESSION["errors"][1] = "Please enter a message";
        } else {
            $r++;
        }
    }
}