<?php

namespace xenonmc\xpframe\apps\contact\controllers;

use mysqli;
use xenonmc\xpframe\core\mvc\MVC;

class Main
{
    public function start(MVC $mvc)
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $conn = new mysqli("localhost", "root", "helloworld", "xenonmc");
            $conn->query("INSERT INTO cta (email, msg) VALUES ('" . $_POST["email"] . "', '" . $_POST["message"] ."')");
            $r = $conn->query("SELECT * FROM cta");
            while ($cta = $r->fetch_assoc()) {
                echo $cta["email"] . "<br>";
            }
            return null;
        }
        // Render the contact form
        $mvc->view->render([
            "template" => [
                "e" => "a"
            ],
            "layout" => [
                "brand" => "XENONMC",
                "project" => "XPFRAME"
            ]
        ], "Default", "Contact", "Main");
    }
}