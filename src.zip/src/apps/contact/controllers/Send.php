<?php

namespace xenonmc\xpframe\apps\contact\controllers;

class Send
{
    public function start()
    {
        // run contact validation
        $val = new Validator($_POST);
        header("Location: /contact");
    }
}