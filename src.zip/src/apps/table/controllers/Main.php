<?php

namespace xenonmc\xpframe\apps\table\controllers;

use mysqli;
use xenonmc\xpframe\core\mvc\MVC;

class Main
{
    public function start(MVC $mvc)
    {
        // logic
        $conn = new mysqli("localhost", "root", "helloworld", "xenonmc");
        $result = $conn->query("SELECT * FROM tablee");
        
        // build result
        $out = [];
        while ($row = $result->fetch_assoc()) {
            array_push($out, $row);
        }

        // render
        $mvc->view->render([
            "template" => [
                "out" => $out
            ],
            "layout" => [

            ]
        ], "Default", "Table", "Main", false);
    }
}